package com.personal.debtmanager;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
