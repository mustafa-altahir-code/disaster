(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e={};(function e(t,n,r,i){var a=!!(t.Worker&&t.Blob&&t.Promise&&t.OffscreenCanvas&&t.OffscreenCanvasRenderingContext2D&&t.HTMLCanvasElement&&t.HTMLCanvasElement.prototype.transferControlToOffscreen&&t.URL&&t.URL.createObjectURL),o=typeof Path2D==`function`&&typeof DOMMatrix==`function`,s=(function(){if(!t.OffscreenCanvas)return!1;try{var e=new OffscreenCanvas(1,1),n=e.getContext(`2d`);n.fillRect(0,0,1,1);var r=e.transferToImageBitmap();n.createPattern(r,`no-repeat`)}catch{return!1}return!0})();function c(){}function l(e){var r=n.exports.Promise,i=r===void 0?t.Promise:r;return typeof i==`function`?new i(e):(e(c,c),null)}var u=(function(e,t){return{transform:function(n){if(e)return n;if(t.has(n))return t.get(n);var r=new OffscreenCanvas(n.width,n.height);return r.getContext(`2d`).drawImage(n,0,0),t.set(n,r),r},clear:function(){t.clear()}}})(s,new Map),d=function(){var e,t,n={},r=0;return typeof requestAnimationFrame==`function`&&typeof cancelAnimationFrame==`function`?(e=function(e){var t=Math.random();return n[t]=requestAnimationFrame(function i(a){r===a||r+16-1<a?(r=a,delete n[t],e()):n[t]=requestAnimationFrame(i)}),t},t=function(e){n[e]&&cancelAnimationFrame(n[e])}):(e=function(e){return setTimeout(e,16)},t=function(e){return clearTimeout(e)}),{frame:e,cancel:t}}(),f=(function(){var t,n,i={};function o(e){function t(t,n){e.postMessage({options:t||{},callback:n})}e.init=function(t){var n=t.transferControlToOffscreen();e.postMessage({canvas:n},[n])},e.fire=function(r,a,o){if(n)return t(r,null),n;var s=Math.random().toString(36).slice(2);return n=l(function(a){function c(t){t.data.callback===s&&(delete i[s],e.removeEventListener(`message`,c),n=null,u.clear(),o(),a())}e.addEventListener(`message`,c),t(r,s),i[s]=c.bind(null,{data:{callback:s}})}),n},e.reset=function(){for(var t in e.postMessage({reset:!0}),i)i[t](),delete i[t]}}return function(){if(t)return t;if(!r&&a){var n=[`var CONFETTI, SIZE = {}, module = {};`,`(`+e.toString()+`)(this, module, true, SIZE);`,`onmessage = function(msg) {`,`  if (msg.data.options) {`,`    CONFETTI(msg.data.options).then(function () {`,`      if (msg.data.callback) {`,`        postMessage({ callback: msg.data.callback });`,`      }`,`    });`,`  } else if (msg.data.reset) {`,`    CONFETTI && CONFETTI.reset();`,`  } else if (msg.data.resize) {`,`    SIZE.width = msg.data.resize.width;`,`    SIZE.height = msg.data.resize.height;`,`  } else if (msg.data.canvas) {`,`    SIZE.width = msg.data.canvas.width;`,`    SIZE.height = msg.data.canvas.height;`,`    CONFETTI = module.exports.create(msg.data.canvas);`,`  }`,`}`].join(`
`);try{t=new Worker(URL.createObjectURL(new Blob([n])))}catch(e){return typeof console<`u`&&typeof console.warn==`function`&&console.warn(`🎊 Could not load worker`,e),null}o(t)}return t}})(),p={particleCount:50,angle:90,spread:45,startVelocity:45,decay:.9,gravity:1,drift:0,ticks:200,x:.5,y:.5,shapes:[`square`,`circle`],zIndex:100,colors:[`#26ccff`,`#a25afd`,`#ff5e7e`,`#88ff5a`,`#fcff42`,`#ffa62d`,`#ff36ff`],disableForReducedMotion:!1,scalar:1};function m(e,t){return t?t(e):e}function h(e){return e!=null}function g(e,t,n){return m(e&&h(e[t])?e[t]:p[t],n)}function _(e){return e<0?0:Math.floor(e)}function v(e,t){return Math.floor(Math.random()*(t-e))+e}function y(e){return parseInt(e,16)}function b(e){return e.map(x)}function x(e){var t=String(e).replace(/[^0-9a-f]/gi,``);return t.length<6&&(t=t[0]+t[0]+t[1]+t[1]+t[2]+t[2]),{r:y(t.substring(0,2)),g:y(t.substring(2,4)),b:y(t.substring(4,6))}}function S(e){var t=g(e,`origin`,Object);return t.x=g(t,`x`,Number),t.y=g(t,`y`,Number),t}function C(e){e.width=document.documentElement.clientWidth,e.height=document.documentElement.clientHeight}function w(e){var t=e.getBoundingClientRect();e.width=t.width,e.height=t.height}function T(e){var t=document.createElement(`canvas`);return t.style.position=`fixed`,t.style.top=`0px`,t.style.left=`0px`,t.style.pointerEvents=`none`,t.style.zIndex=e,t}function E(e,t,n,r,i,a,o,s,c){e.save(),e.translate(t,n),e.rotate(a),e.scale(r,i),e.arc(0,0,1,o,s,c),e.restore()}function ee(e){var t=e.angle*(Math.PI/180),n=e.spread*(Math.PI/180);return{x:e.x,y:e.y,wobble:Math.random()*10,wobbleSpeed:Math.min(.11,Math.random()*.1+.05),velocity:e.startVelocity*.5+Math.random()*e.startVelocity,angle2D:-t+(.5*n-Math.random()*n),tiltAngle:(Math.random()*.5+.25)*Math.PI,color:e.color,shape:e.shape,tick:0,totalTicks:e.ticks,decay:e.decay,drift:e.drift,random:Math.random()+2,tiltSin:0,tiltCos:0,wobbleX:0,wobbleY:0,gravity:e.gravity*3,ovalScalar:.6,scalar:e.scalar,flat:e.flat}}function D(e,t){t.x+=Math.cos(t.angle2D)*t.velocity+t.drift,t.y+=Math.sin(t.angle2D)*t.velocity+t.gravity,t.velocity*=t.decay,t.flat?(t.wobble=0,t.wobbleX=t.x+10*t.scalar,t.wobbleY=t.y+10*t.scalar,t.tiltSin=0,t.tiltCos=0,t.random=1):(t.wobble+=t.wobbleSpeed,t.wobbleX=t.x+10*t.scalar*Math.cos(t.wobble),t.wobbleY=t.y+10*t.scalar*Math.sin(t.wobble),t.tiltAngle+=.1,t.tiltSin=Math.sin(t.tiltAngle),t.tiltCos=Math.cos(t.tiltAngle),t.random=Math.random()+2);var n=t.tick++/t.totalTicks,r=t.x+t.random*t.tiltCos,i=t.y+t.random*t.tiltSin,a=t.wobbleX+t.random*t.tiltCos,s=t.wobbleY+t.random*t.tiltSin;if(e.fillStyle=`rgba(`+t.color.r+`, `+t.color.g+`, `+t.color.b+`, `+(1-n)+`)`,e.beginPath(),o&&t.shape.type===`path`&&typeof t.shape.path==`string`&&Array.isArray(t.shape.matrix))e.fill(M(t.shape.path,t.shape.matrix,t.x,t.y,Math.abs(a-r)*.1,Math.abs(s-i)*.1,Math.PI/10*t.wobble));else if(t.shape.type===`bitmap`){var c=Math.PI/10*t.wobble,l=Math.abs(a-r)*.1,d=Math.abs(s-i)*.1,f=t.shape.bitmap.width*t.scalar,p=t.shape.bitmap.height*t.scalar,m=new DOMMatrix([Math.cos(c)*l,Math.sin(c)*l,-Math.sin(c)*d,Math.cos(c)*d,t.x,t.y]);m.multiplySelf(new DOMMatrix(t.shape.matrix));var h=e.createPattern(u.transform(t.shape.bitmap),`no-repeat`);h.setTransform(m),e.globalAlpha=1-n,e.fillStyle=h,e.fillRect(t.x-f/2,t.y-p/2,f,p),e.globalAlpha=1}else if(t.shape===`circle`)e.ellipse?e.ellipse(t.x,t.y,Math.abs(a-r)*t.ovalScalar,Math.abs(s-i)*t.ovalScalar,Math.PI/10*t.wobble,0,2*Math.PI):E(e,t.x,t.y,Math.abs(a-r)*t.ovalScalar,Math.abs(s-i)*t.ovalScalar,Math.PI/10*t.wobble,0,2*Math.PI);else if(t.shape===`star`)for(var g=Math.PI/2*3,_=4*t.scalar,v=8*t.scalar,y=t.x,b=t.y,x=5,S=Math.PI/x;x--;)y=t.x+Math.cos(g)*v,b=t.y+Math.sin(g)*v,e.lineTo(y,b),g+=S,y=t.x+Math.cos(g)*_,b=t.y+Math.sin(g)*_,e.lineTo(y,b),g+=S;else e.moveTo(Math.floor(t.x),Math.floor(t.y)),e.lineTo(Math.floor(t.wobbleX),Math.floor(i)),e.lineTo(Math.floor(a),Math.floor(s)),e.lineTo(Math.floor(r),Math.floor(t.wobbleY));return e.closePath(),e.fill(),t.tick<t.totalTicks}function O(e,t,n,a,o){var s=t.slice(),c=e.getContext(`2d`),f,p,m=l(function(t){function l(){f=p=null,c.clearRect(0,0,a.width,a.height),u.clear(),o(),t()}function m(){r&&(a.width!==i.width||a.height!==i.height)&&(a.width=e.width=i.width,a.height=e.height=i.height),!a.width&&!a.height&&(n(e),a.width=e.width,a.height=e.height),c.clearRect(0,0,a.width,a.height),s=s.filter(function(e){return D(c,e)}),s.length?f=d.frame(m):l()}f=d.frame(m),p=l});return{addFettis:function(e){return s=s.concat(e),m},canvas:e,promise:m,reset:function(){f&&d.cancel(f),p&&p()}}}function k(e,n){var r=!e,i=!!g(n||{},`resize`),o=!1,s=g(n,`disableForReducedMotion`,Boolean),c=a&&g(n||{},`useWorker`)?f():null,u=r?C:w,d=e&&c?!!e.__confetti_initialized:!1,p=typeof matchMedia==`function`&&matchMedia(`(prefers-reduced-motion)`).matches,m;function h(t,n,r){for(var i=g(t,`particleCount`,_),a=g(t,`angle`,Number),o=g(t,`spread`,Number),s=g(t,`startVelocity`,Number),c=g(t,`decay`,Number),l=g(t,`gravity`,Number),d=g(t,`drift`,Number),f=g(t,`colors`,b),p=g(t,`ticks`,Number),h=g(t,`shapes`),y=g(t,`scalar`),x=!!g(t,`flat`),C=S(t),w=i,T=[],E=e.width*C.x,D=e.height*C.y;w--;)T.push(ee({x:E,y:D,angle:a,spread:o,startVelocity:s,color:f[w%f.length],shape:h[v(0,h.length)],ticks:p,decay:c,gravity:l,drift:d,scalar:y,flat:x}));return m?m.addFettis(T):(m=O(e,T,u,n,r),m.promise)}function y(n){var a=s||g(n,`disableForReducedMotion`,Boolean),f=g(n,`zIndex`,Number);if(a&&p)return l(function(e){e()});r&&m?e=m.canvas:r&&!e&&(e=T(f),document.body.appendChild(e)),i&&!d&&u(e);var _={width:e.width,height:e.height};c&&!d&&c.init(e),d=!0,c&&(e.__confetti_initialized=!0);function v(){if(c){var t={getBoundingClientRect:function(){if(!r)return e.getBoundingClientRect()}};u(t),c.postMessage({resize:{width:t.width,height:t.height}})}else _.width=_.height=null}function y(){m=null,i&&(o=!1,t.removeEventListener(`resize`,v)),r&&e&&(document.body.contains(e)&&document.body.removeChild(e),e=null,d=!1)}return i&&!o&&(o=!0,t.addEventListener(`resize`,v,!1)),c?c.fire(n,_,y):h(n,_,y)}return y.reset=function(){c&&c.reset(),m&&m.reset()},y}var A;function j(){return A||=k(null,{useWorker:!0,resize:!0}),A}function M(e,t,n,r,i,a,o){var s=new Path2D(e),c=new Path2D;c.addPath(s,new DOMMatrix(t));var l=new Path2D;return l.addPath(c,new DOMMatrix([Math.cos(o)*i,Math.sin(o)*i,-Math.sin(o)*a,Math.cos(o)*a,n,r])),l}function N(e){if(!o)throw Error(`path confetti are not supported in this browser`);var t,n;typeof e==`string`?t=e:(t=e.path,n=e.matrix);var r=new Path2D(t),i=document.createElement(`canvas`).getContext(`2d`);if(!n){for(var a=1e3,s=a,c=a,l=0,u=0,d,f,p=0;p<a;p+=2)for(var m=0;m<a;m+=2)i.isPointInPath(r,p,m,`nonzero`)&&(s=Math.min(s,p),c=Math.min(c,m),l=Math.max(l,p),u=Math.max(u,m));d=l-s,f=u-c;var h=10,g=Math.min(h/d,h/f);n=[g,0,0,g,-Math.round(d/2+s)*g,-Math.round(f/2+c)*g]}return{type:`path`,path:t,matrix:n}}function P(e){var t,n=1,r=`#000000`,i=`"Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji", "EmojiOne Color", "Android Emoji", "Twemoji Mozilla", "system emoji", sans-serif`;typeof e==`string`?t=e:(t=e.text,n=`scalar`in e?e.scalar:n,i=`fontFamily`in e?e.fontFamily:i,r=`color`in e?e.color:r);var a=10*n,o=``+a+`px `+i,s=new OffscreenCanvas(a,a),c=s.getContext(`2d`);c.font=o;var l=c.measureText(t),u=Math.ceil(l.actualBoundingBoxRight+l.actualBoundingBoxLeft),d=Math.ceil(l.actualBoundingBoxAscent+l.actualBoundingBoxDescent),f=2,p=l.actualBoundingBoxLeft+f,m=l.actualBoundingBoxAscent+f;u+=f+f,d+=f+f,s=new OffscreenCanvas(u,d),c=s.getContext(`2d`),c.font=o,c.fillStyle=r,c.fillText(t,p,m);var h=1/n;return{type:`bitmap`,bitmap:s.transferToImageBitmap(),matrix:[h,0,0,h,-u*h/2,-d*h/2]}}n.exports=function(){return j().apply(this,arguments)},n.exports.reset=function(){j().reset()},n.exports.create=k,n.exports.shapeFromPath=N,n.exports.shapeFromText=P})((function(){return typeof window<`u`?window:typeof self<`u`?self:this||{}})(),e,!1);var t=e.exports;e.exports.create;var n=`DebtManagerAndroidDB_v5`,r=`DebtManagerDB_v4`,i=`debts`,a=`settings`,o=null;async function s(){return o||new Promise((e,t)=>{let r=indexedDB.open(n,1);r.onupgradeneeded=e=>{let t=e.target.result;if(!t.objectStoreNames.contains(i)){let e=t.createObjectStore(i,{keyPath:`id`,autoIncrement:!0});e.createIndex(`name`,`name`,{unique:!1}),e.createIndex(`type`,`type`,{unique:!1}),e.createIndex(`dueDate`,`dueDate`,{unique:!1}),e.createIndex(`status`,`status`,{unique:!1})}t.objectStoreNames.contains(a)||t.createObjectStore(a,{keyPath:`key`})},r.onsuccess=async t=>{o=t.target.result,await c(),e(o)},r.onerror=e=>{console.error(`Database open error:`,e.target.error),t(e.target.error)}})}async function c(){try{if((await l()).length>0)return;let e=await new Promise(e=>{let t=indexedDB.open(r);t.onsuccess=t=>{let n=t.target.result;if(n.objectStoreNames.contains(`debts`)){let t=n.transaction(`debts`,`readonly`).objectStore(`debts`).getAll();t.onsuccess=()=>{n.close(),e(t.result||[])},t.onerror=()=>{n.close(),e([])}}else n.close(),e([])},t.onerror=()=>e([])});if(e&&e.length>0){console.log(`Migrating ${e.length} debts from legacy DB...`);for(let t of e){let e={...t};delete e.id,await d(e)}}}catch(e){console.warn(`Migration check completed with no action:`,e)}}async function l(){let e=await s();return new Promise((t,n)=>{try{let r=e.transaction(i,`readonly`).objectStore(i).getAll();r.onsuccess=()=>t(r.result||[]),r.onerror=e=>n(e.target.error)}catch(e){n(e)}})}async function u(e){let t=await s();return new Promise((n,r)=>{try{let a=t.transaction(i,`readonly`).objectStore(i).get(Number(e));a.onsuccess=()=>n(a.result||null),a.onerror=e=>r(e.target.error)}catch(e){r(e)}})}async function d(e){let t=await s();return new Promise((n,r)=>{try{let a=t.transaction(i,`readwrite`).objectStore(i),o={...e};o.id?o.id=Number(o.id):delete o.id,o.updatedAt=new Date().toISOString(),o.createdAt||=new Date().toISOString();let s=a.put(o);s.onsuccess=()=>n(s.result),s.onerror=e=>r(e.target.error)}catch(e){r(e)}})}async function f(e){let t=await s();return new Promise((n,r)=>{try{let a=t.transaction(i,`readwrite`).objectStore(i).delete(Number(e));a.onsuccess=()=>n(!0),a.onerror=e=>r(e.target.error)}catch(e){r(e)}})}async function p(){let e=await s();return new Promise((t,n)=>{try{let r=e.transaction(i,`readwrite`).objectStore(i).clear();r.onsuccess=()=>t(!0),r.onerror=e=>n(e.target.error)}catch(e){n(e)}})}async function m(e,t=null){let n=await s();return new Promise(r=>{try{let i=n.transaction(a,`readonly`).objectStore(a).get(e);i.onsuccess=()=>r(i.result?i.result.value:t),i.onerror=()=>r(t)}catch{r(t)}})}async function h(e,t){let n=await s();return new Promise((r,i)=>{try{let o=n.transaction(a,`readwrite`).objectStore(a).put({key:e,value:t});o.onsuccess=()=>r(!0),o.onerror=e=>i(e.target.error)}catch(e){i(e)}})}function g(e,t=``){if(e==null||isNaN(e))return`0 ${t}`.trim();let n=Number(e),r=n.toLocaleString(`en-US`,{minimumFractionDigits:Number.isInteger(n)?0:2,maximumFractionDigits:2});return t?`${r} ${t}`:r}function _(e){if(!e)return 0;let t=String(e).replace(/,/g,``).trim(),n=parseFloat(t);return isNaN(n)?0:n}function v(e){let t=e.selectionStart,n=e.value.length,r=e.value.replace(/,/g,``);if(r===``)return;if(!/^\d*\.?\d*$/.test(r)){e.value=e.value.slice(0,-1);return}let i=r.split(`.`);i[0]=i[0].replace(/\B(?=(\d{3})+(?!\d))/g,`,`),e.value=i.join(`.`);let a=e.value.length;e.setSelectionRange(t+(a-n),t+(a-n))}function y(){let e=new Date;return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}function b(e){if(!e)return new Date;let t=e.split(`-`);return new Date(t[0],t[1]-1,t[2])}function x(e,t){let n=b(e),r=b(t).getTime()-n.getTime();return Math.round(r/864e5)}function S(e){if(!e)return`-`;let t=e.split(`-`);return t.length===3?`${t[2]}/${t[1]}/${t[0]}`:e}function C(e){return(e.payments||[]).reduce((e,t)=>e+(Number(t.amount)||0),0)}function w(e){let t=Number(e.amount)||0,n=C(e);return Math.max(0,t-n)}function T(e){let t=Number(e.amount)||0;if(t<=0)return 100;let n=C(e)/t*100;return Math.min(100,Math.max(0,Math.round(n*10)/10))}function E(e){let t=Number(e.amount)||0,n=C(e),r=Math.max(0,t-n),i=T(e),a=x(y(),e.dueDate);if(r<=0&&t>0)return{code:`PAID_FULL`,title:`تم السداد بالكامل`,badgeClass:`badge-success`,icon:`check-circle-2`,daysDiff:a,percentage:100,isPartiallyPaid:!1,isOverdue:!1,priority:6,subText:`تمت تصفية كامل المبلغ بنجاح 🎉`};if(a<0){let e=Math.abs(a);return{code:`OVERDUE`,title:`متأخر (${e} يوم)`,badgeClass:`badge-danger`,icon:`alert-triangle`,daysDiff:a,percentage:i,isPartiallyPaid:n>0,isOverdue:!0,priority:1,subText:n>0?`سداد جزئي ${i}% ولكن متأخر ${e} يوم`:`تجاوز موعد الاستحقاق بـ ${e} يوم`}}return a===0?{code:`DUE_TODAY`,title:`مستحق اليوم`,badgeClass:`badge-urgent`,icon:`alarm-clock`,daysDiff:0,percentage:i,isPartiallyPaid:n>0,isOverdue:!1,priority:2,subText:n>0?`سداد جزئي ${i}% - المتبقي مستحق اليوم`:`موعد السداد يحل اليوم!`}:a<=(e.remindDays!==void 0&&e.remindDays>0?e.remindDays:3)?{code:`DUE_SOON`,title:`مستحق بعد ${a} يوم`,badgeClass:`badge-warning`,icon:`clock`,daysDiff:a,percentage:i,isPartiallyPaid:n>0,isOverdue:!1,priority:3,subText:n>0?`سداد جزئي ${i}% - تبقى ${a} يوم`:`يتبقى ${a} يوم على تاريخ الاستحقاق`}:n>0&&r>0?{code:`PARTIALLY_PAID`,title:`سداد جزئي (${i}%)`,badgeClass:`badge-info`,icon:`pie-chart`,daysDiff:a,percentage:i,isPartiallyPaid:!0,isOverdue:!1,priority:4,subText:`تم تسديد ${g(n,e.currency)} ومتبقي ${a} يوم`}:{code:`ACTIVE`,title:`نشط (بعد ${a} يوم)`,badgeClass:`badge-neutral`,icon:`calendar`,daysDiff:a,percentage:0,isPartiallyPaid:!1,isOverdue:!1,priority:5,subText:`مستحق بتاريخ ${S(e.dueDate)}`}}function ee(e){let t=w(e),n=E(e),r=g(t,e.currency||`SAR`),i=S(e.dueDate),a=``;a=e.type===`لي عند شخص`?n.code===`OVERDUE`?`السلام عليكم ورحمة الله وبركاته أخي ${e.name}،\nنود التذكير بلطف بخصوص المبلغ المتبقي وقدره *${r}*، والذي كان مستحقاً بتاريخ ${i}.\nنأمل التكرم بمراجعة الأمر، وشكراً جزيلاً لتعاونكم.`:n.code===`DUE_TODAY`?`السلام عليكم أخي ${e.name}،\nتذكير ودي بأن موعد استحقاق المبلغ المتبقي وقدره *${r}* يحل اليوم (${i}).\nمع فائق الشكر والتقدير.`:`السلام عليكم أخي ${e.name}،\nتحية طيبة، تذكير بموعد استحقاق المبلغ المتبقي وقدره *${r}* بتاريخ ${i}.\nدمتم بخير.`:`السلام عليكم أخي ${e.name}،\nأود إعلامك بأني على تواصل معك بخصوص المبلغ المستحق لكم وقدره *${r}* لتنسيق السداد.\nشكراً جزيلاً.`;let o=(e.phone||``).replace(/[^0-9]/g,``);o.startsWith(`05`)?o=`966`+o.substring(1):o.startsWith(`01`)&&(o=`20`+o.substring(1));let s=encodeURIComponent(a);return o?`https://wa.me/${o}?text=${s}`:`https://wa.me/?text=${s}`}function D(e,t=`info`,n=3500){let r=document.getElementById(`toast-container`);if(!r)return;let i=document.createElement(`div`);i.className=`toast toast-${t}`;let a=`✨`;t===`success`&&(a=`✅`),t===`error`&&(a=`❌`),t===`warning`&&(a=`⚠️`),i.innerHTML=`
    <span class="toast-icon">${a}</span>
    <span class="toast-msg">${e}</span>
  `,r.appendChild(i),requestAnimationFrame(()=>{i.classList.add(`show`)}),setTimeout(()=>{i.classList.remove(`show`),setTimeout(()=>i.remove(),300)},n)}function O(e){return new Promise((t,n)=>{let r=new FileReader;r.onload=()=>t({name:e.name,size:e.size,type:e.type,data:r.result}),r.onerror=n,r.readAsDataURL(e)})}function k(e){return e?e<1024?e+` B`:e<1048576?(e/1024).toFixed(1)+` KB`:(e/1048576).toFixed(1)+` MB`:`0 B`}var A=``,j=null,M=null,N=!1;function P(e){let t=0;for(let n=0;n<e.length;n++){let r=e.charCodeAt(n);t=(t<<5)-t+r,t|=0}return`pin_v1_`+Math.abs(t).toString(36)+e.length}async function te(e){M=e,j=await m(`security_pin_hash`,null),N=await m(`privacy_mode`,!1)===!0,j?ae():(F(),M&&M()),ie()}function ne(){return N}async function re(){N=!N,await h(`privacy_mode`,N),ie(),window.dispatchEvent(new CustomEvent(`app:state-changed`)),D(N?`تم تفعيل وضع الخصوصية وإخفاء المبالغ 👁️`:`تم إظهار المبالغ المالية 👁️`)}function ie(){let e=document.getElementById(`privacy-toggle-btn`);e&&(e.innerHTML=N?`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>`:`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>`,e.title=N?`إظهار المبالغ`:`إخفاء المبالغ للخصوصية`)}function ae(){j?(A=``,oe()):D(`لم يتم تفعيل رمز PIN بعد. يمكنك تفعيله من الإعدادات.`,`warning`)}function oe(){let e=document.getElementById(`lock-screen`);if(!e)return;e.classList.remove(`hidden`),I();let t=document.getElementById(`lock-error`);t&&(t.textContent=``)}function F(){let e=document.getElementById(`lock-screen`);e&&e.classList.add(`hidden`)}function I(){document.querySelectorAll(`.pin-dot`).forEach((e,t)=>{t<A.length?e.classList.add(`filled`):e.classList.remove(`filled`)})}function se(e){A.length>=4||(A+=e,I(),A.length===4&&setTimeout(le,150))}function ce(){A.length>0&&(A=A.slice(0,-1),I())}function le(){if(P(A)===j)A=``,I(),F(),D(`تم فتح القفل بنجاح`,`success`),M&&M();else{let e=document.querySelector(`.pin-dots-container`);e&&(e.classList.add(`shake`),setTimeout(()=>e.classList.remove(`shake`),500));let t=document.getElementById(`lock-error`);t&&(t.textContent=`رمز PIN غير صحيح، حاول مرة أخرى`),A=``,setTimeout(I,400)}}async function ue(e){if(!e||e.length!==4)throw Error(`رمز PIN يجب أن يتكون من 4 أرقام بالضبط`);j=P(e),await h(`security_pin_hash`,j),D(`تم تفعيل رمز الحماية PIN بنجاح 🔒`,`success`)}async function de(){j=null,await h(`security_pin_hash`,null),F(),D(`تم إلغاء رمز الحماية بنجاح 🔓`)}async function fe(){return!!await m(`security_pin_hash`,null)}var L=[],R=`tab-home`,z=`all`,B=``,V=!1,H=[],U=[];function W(e,t=`SAR`){return ne()?`•••• ${t}`:g(e,t)}async function pe(){try{await s(),V=await m(`theme_dark`,!1)===!0,me(),he(),Te(),ye(),Me(),ge(),await te(async()=>{await G(),Ne()}),window.addEventListener(`app:state-changed`,()=>{K()})}catch(e){console.error(`App init error:`,e),D(`حدث خطأ أثناء تحميل التطبيق`,`error`)}}async function G(){try{L=await l(),L.sort((e,t)=>{let n=E(e),r=E(t);return n.priority===r.priority?new Date(e.dueDate)-new Date(t.dueDate):n.priority-r.priority}),K()}catch(e){console.error(`Data refresh error:`,e)}}function K(){_e(),R===`tab-home`?ve():R===`tab-debts`?Y():R===`tab-persons`?Se():R===`tab-reports`?Ce():R===`tab-settings`&&X()}function me(){let e=document.getElementById(`dark-mode-icon`);V?(document.body.classList.add(`dark-mode`),e&&(e.textContent=`☀️`)):(document.body.classList.remove(`dark-mode`),e&&(e.textContent=`🌙`))}function he(){let e=document.querySelectorAll(`.nav-tab`);e.forEach(t=>{t.addEventListener(`click`,()=>{e.forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`);let n=t.dataset.tab;document.querySelectorAll(`.tab-pane`).forEach(e=>e.classList.remove(`active`));let r=document.getElementById(n);r&&r.classList.add(`active`),R=n,K(),window.scrollTo({top:0,behavior:`smooth`})})}),document.getElementById(`fab-add-debt`).addEventListener(`click`,()=>{Ee()});let t=document.getElementById(`view-all-debts-btn`);t&&t.addEventListener(`click`,()=>{q(`tab-debts`)}),document.querySelectorAll(`.pill-card`).forEach(e=>{e.addEventListener(`click`,()=>{z=e.dataset.navFilter,q(`tab-debts`),J()})})}function q(e){let t=document.querySelector(`.nav-tab[data-tab="${e}"]`);t&&t.click()}function ge(){document.getElementById(`dark-mode-btn`).addEventListener(`click`,async()=>{V=!V,await h(`theme_dark`,V),me()}),document.getElementById(`privacy-toggle-btn`).addEventListener(`click`,()=>{re()}),document.getElementById(`quick-lock-btn`).addEventListener(`click`,async()=>{await fe()?ae():(D(`قم أولاً بتعيين رمز PIN من شاشة الإعدادات`,`warning`),je())})}function _e(){let e=0,t=0,n=0,r=0,i=0,a=0,o=0;L.forEach(s=>{let c=Number(s.amount)||0,l=w(s),u=E(s);s.type===`لي عند شخص`?(e+=c,t+=l):(n+=c,r+=l),u.code===`OVERDUE`&&i++,u.isPartiallyPaid&&u.code!==`PAID_FULL`&&a++,u.code===`PAID_FULL`&&o++});let s=t-r,c=document.getElementById(`dash-lana-amount`),l=document.getElementById(`dash-lana-sub`),u=document.getElementById(`dash-alayna-amount`),d=document.getElementById(`dash-alayna-sub`),f=document.getElementById(`dash-net-amount`),p=document.getElementById(`dash-net-sub`);c&&(c.textContent=W(e)),l&&(l.textContent=`المتبقي للتحصيل: ${W(t)}`),u&&(u.textContent=W(n)),d&&(d.textContent=`المتبقي للدفع: ${W(r)}`),f&&(f.textContent=W(s),f.style.color=s>=0?`var(--lana-color)`:`var(--alayna-color)`),p&&(p.textContent=s>=0?`فائض لصالحك 🟢`:`عجز مستحق عليك 🔴`);let m=document.getElementById(`count-overdue`),h=document.getElementById(`count-partial`),g=document.getElementById(`count-completed`);m&&(m.textContent=i),h&&(h.textContent=a),g&&(g.textContent=o)}function ve(){let e=document.getElementById(`urgent-alerts-container`),t=document.getElementById(`home-recent-debts`),n=L.filter(e=>{let t=E(e);return t.code===`OVERDUE`||t.code===`DUE_TODAY`});n.length>0?(e.innerHTML=`
      <div class="urgent-banner">
        <div class="urgent-banner-content">
          <span>⚠️</span>
          <span>لديك <strong>${n.length}</strong> معاملات مالية متأخرة أو مستحقة اليوم!</span>
        </div>
        <button class="btn-sm-action" id="view-urgent-btn" style="background:#fff; color:#b91c1c;">معاينة</button>
      </div>
    `,document.getElementById(`view-urgent-btn`)?.addEventListener(`click`,()=>{z=`overdue`,q(`tab-debts`),J()})):e.innerHTML=``;let r=L.slice(0,5);r.length===0?t.innerHTML=`
      <div class="empty-state">
        <div class="empty-state-icon">📝</div>
        <h3>لا توجد معاملات مسجلة حتى الآن</h3>
        <p>اضغط على زر "دين جديد" بالأسفل لبدء تسجيل أول دين.</p>
      </div>
    `:(t.innerHTML=r.map(e=>be(e)).join(``),xe(t))}function ye(){let e=document.getElementById(`search-debts-input`);e&&e.addEventListener(`input`,e=>{B=e.target.value.trim().toLowerCase(),Y()});let t=document.querySelectorAll(`.chip-btn`);t.forEach(e=>{e.addEventListener(`click`,()=>{t.forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),z=e.dataset.filter,Y()})})}function J(){document.querySelectorAll(`.chip-btn`).forEach(e=>{e.dataset.filter===z?e.classList.add(`active`):e.classList.remove(`active`)})}function Y(){let e=document.getElementById(`debts-cards-container`);if(!e)return;let t=L.filter(e=>{if(B){let t=(e.name||``).toLowerCase().includes(B),n=(e.phone||``).includes(B),r=(e.category||``).toLowerCase().includes(B),i=(e.notes||``).toLowerCase().includes(B);if(!t&&!n&&!r&&!i)return!1}let t=E(e);return z===`all`?!0:z===`lana`?e.type===`لي عند شخص`:z===`alayna`?e.type===`علي لشخص`:z===`overdue`?t.code===`OVERDUE`||t.code===`DUE_TODAY`:z===`partial`?t.isPartiallyPaid&&t.code!==`PAID_FULL`:z===`due_soon`?t.code===`DUE_SOON`||t.code===`DUE_TODAY`:z!==`completed`||t.code===`PAID_FULL`});t.length===0?e.innerHTML=`
      <div class="empty-state">
        <div class="empty-state-icon">🔍</div>
        <h3>لا توجد نتائج مطابقة</h3>
        <p>جرب تغيير خيارات التصفية أو كلمة البحث.</p>
      </div>
    `:(e.innerHTML=t.map(e=>be(e)).join(``),xe(e))}function be(e){let t=E(e),n=Number(e.amount)||0,r=C(e),i=w(e),a=e.currency||`SAR`,o=e.type===`لي عند شخص`,s=(e.name||`؟`).trim().charAt(0),c=e.phone||``,l=``;return t.code===`PAID_FULL`?l=`fill-completed`:t.isPartiallyPaid&&(l=`fill-partial`),`
    <div class="debt-card" data-debt-id="${e.id}">
      <div class="debt-card-header">
        <div class="debt-person-info">
          <div class="person-avatar">${s}</div>
          <div class="person-meta">
            <h3>${e.name}</h3>
            ${c?`<div class="phone-text">📞 ${c}</div>`:``}
          </div>
        </div>

        <div style="display:flex; flex-direction:column; align-items:flex-end; gap:4px;">
          <span class="type-pill ${o?`type-lana`:`type-alayna`}">
            ${o?`💰 لي عنده`:`💸 عليّ له`}
          </span>
          <span class="status-badge ${t.badgeClass}">
            ${t.title}
          </span>
        </div>
      </div>

      <!-- Financial Figures Row -->
      <div class="debt-amount-row">
        <div class="amount-col">
          <div class="amount-label">المبلغ الكلي</div>
          <div class="amount-val">${W(n,a)}</div>
        </div>
        <div class="amount-col">
          <div class="amount-label">المسدد</div>
          <div class="amount-val" style="color:var(--lana-color);">${W(r,a)}</div>
        </div>
        <div class="amount-col rem-col">
          <div class="amount-label">المتبقي</div>
          <div class="amount-val">${W(i,a)}</div>
        </div>
      </div>

      <!-- Enhanced Progress Bar -->
      <div class="progress-container">
        <div class="progress-header">
          <span>نسبة السداد: ${t.percentage}%</span>
          <span>${t.subText}</span>
        </div>
        <div class="progress-track">
          <div class="progress-fill ${l}" style="width: ${t.percentage}%;"></div>
        </div>
      </div>

      <!-- Card Actions Footer -->
      <div class="debt-card-footer">
        <div class="card-actions-left">
          ${i>0?`<button class="btn-sm-action btn-pay action-pay-btn" data-id="${e.id}">⚡ دفع</button>`:``}
          <button class="btn-sm-action action-view-btn" data-id="${e.id}">👁️ تفاصيل</button>
          ${c?`<a href="${ee(e)}" target="_blank" class="btn-sm-action btn-whatsapp" title="تذكير عبر واتساب">💬 تذكير</a>`:``}
        </div>

        <div style="display:flex; gap:6px;">
          <button class="icon-btn action-edit-btn" data-id="${e.id}" title="تعديل">✏️</button>
          <button class="icon-btn action-del-btn" data-id="${e.id}" title="حذف" style="color:var(--danger-color);">🗑️</button>
        </div>
      </div>
    </div>
  `}function xe(e){e.querySelectorAll(`.action-pay-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.stopPropagation();let n=e.dataset.id;$(n)})}),e.querySelectorAll(`.action-view-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.stopPropagation();let n=e.dataset.id;Ae(n)})}),e.querySelectorAll(`.action-edit-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.stopPropagation();let n=e.dataset.id;Ee(n)})}),e.querySelectorAll(`.action-del-btn`).forEach(e=>{e.addEventListener(`click`,async t=>{t.stopPropagation();let n=e.dataset.id;confirm(`هل أنت متأكد من حذف هذه المديونية نهائياً؟`)&&(await f(n),D(`تم حذف المديونية بنجاح`),await G())})})}function Se(){let e=document.getElementById(`persons-ledger-container`);if(!e)return;let t=new Map;if(L.forEach(e=>{let n=(e.name||`بدون اسم`).trim();t.has(n)||t.set(n,{name:n,phone:e.phone||``,debts:[],totalLana:0,totalAlayna:0,paidLana:0,paidAlayna:0,remLana:0,remAlayna:0});let r=t.get(n);r.debts.push(e),!r.phone&&e.phone&&(r.phone=e.phone);let i=Number(e.amount)||0,a=C(e),o=w(e);e.type===`لي عند شخص`?(r.totalLana+=i,r.paidLana+=a,r.remLana+=o):(r.totalAlayna+=i,r.paidAlayna+=a,r.remAlayna+=o)}),t.size===0){e.innerHTML=`
      <div class="empty-state">
        <div class="empty-state-icon">👥</div>
        <h3>لا يوجد أشخاص مسجلين</h3>
        <p>ستظهر الحسابات المجمعة للأشخاص تلقائياً بمجرد إضافة الديون.</p>
      </div>
    `;return}let n=``;t.forEach(e=>{let t=e.remLana-e.remAlayna,r=t>=0;n+=`
      <div class="debt-card" style="border-right: 4px solid ${r?`var(--lana-color)`:`var(--alayna-color)`}">
        <div class="debt-card-header">
          <div class="debt-person-info">
            <div class="person-avatar">${e.name.charAt(0)}</div>
            <div class="person-meta">
              <h3>${e.name}</h3>
              ${e.phone?`<div class="phone-text">📞 ${e.phone}</div>`:``}
            </div>
          </div>
          <span class="type-pill ${r?`type-lana`:`type-alayna`}">
            ${r?`صافي لصالحك: ${W(t)}`:`صافي عليه: ${W(Math.abs(t))}`}
          </span>
        </div>

        <div class="debt-amount-row">
          <div class="amount-col">
            <div class="amount-label">عدد المعاملات</div>
            <div class="amount-val">${e.debts.length}</div>
          </div>
          <div class="amount-col">
            <div class="amount-label">المتبقي لك عنده</div>
            <div class="amount-val" style="color:var(--lana-color);">${W(e.remLana)}</div>
          </div>
          <div class="amount-col">
            <div class="amount-label">المتبقي له عليك</div>
            <div class="amount-val" style="color:var(--alayna-color);">${W(e.remAlayna)}</div>
          </div>
        </div>

        <div class="debt-card-footer">
          <button class="btn-sm-action person-filter-btn" data-person="${e.name}">
            🔍 استعراض كشف حساب (${e.debts.length})
          </button>
          ${e.phone?`<a href="https://wa.me/${e.phone.replace(/[^0-9]/g,``)}" target="_blank" class="btn-sm-action btn-whatsapp">
                  💬 محادثة واتساب
                 </a>`:``}
        </div>
      </div>
    `}),e.innerHTML=n,e.querySelectorAll(`.person-filter-btn`).forEach(e=>{e.addEventListener(`click`,()=>{B=e.dataset.person;let t=document.getElementById(`search-debts-input`);t&&(t.value=B),z=`all`,q(`tab-debts`),J()})})}function Ce(){let e=document.getElementById(`reports-analytics-container`);if(!e)return;let t={},n=L.length,r=0;L.forEach(e=>{let n=e.currency||`SAR`;t[n]||(t[n]={currency:n,totalLana:0,remLana:0,totalAlayna:0,remAlayna:0});let i=Number(e.amount)||0,a=w(e);e.type===`لي عند شخص`?(t[n].totalLana+=i,t[n].remLana+=a):(t[n].totalAlayna+=i,t[n].remAlayna+=a),E(e).code===`PAID_FULL`&&r++});let i=n>0?Math.round(r/n*100):0,a=``;Object.values(t).forEach(e=>{let t=e.remLana-e.remAlayna;a+=`
      <div class="debt-card" style="margin-bottom:12px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
          <h3 style="font-size:1.1rem; font-weight:800;">عملة: ${e.currency}</h3>
          <span class="type-pill ${t>=0?`type-lana`:`type-alayna`}">الصافي: ${W(t,e.currency)}</span>
        </div>
        <div class="debt-amount-row">
          <div class="amount-col">
            <div class="amount-label">لنا (الأصل)</div>
            <div class="amount-val" style="color:var(--lana-color);">${W(e.totalLana,e.currency)}</div>
          </div>
          <div class="amount-col">
            <div class="amount-label">المتبقي لنا</div>
            <div class="amount-val">${W(e.remLana,e.currency)}</div>
          </div>
          <div class="amount-col">
            <div class="amount-label">المتبقي علينا</div>
            <div class="amount-val" style="color:var(--alayna-color);">${W(e.remAlayna,e.currency)}</div>
          </div>
        </div>
      </div>
    `}),e.innerHTML=`
    <!-- Overall Settlement Rate -->
    <div class="card-summary card-net" style="margin-bottom:16px;">
      <div class="summary-header">
        <span class="summary-label">معدل تسوية الديون الكلي</span>
        <span class="summary-badge-icon">📊</span>
      </div>
      <div class="summary-value">${i}%</div>
      <div class="progress-track" style="margin: 8px 0;">
        <div class="progress-fill fill-completed" style="width: ${i}%;"></div>
      </div>
      <div class="summary-subtext">تم سداد ${r} من إجمالي ${n} دين مسجل</div>
    </div>

    <h3 style="font-size:1.05rem; font-weight:800; margin-bottom:10px;">التوزيع المالي حسب العملات</h3>
    ${a||`<p style="color:var(--text-muted);">لا توجد بيانات كافية</p>`}
  `}async function X(){let e=document.getElementById(`settings-content-container`);if(!e)return;let t=await fe();e.innerHTML=`
    <!-- Security Box -->
    <div class="debt-card" style="margin-bottom:16px;">
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <div>
          <h3 style="font-size:1rem; font-weight:800;">🔐 رمز الحماية (PIN Lock)</h3>
          <p style="font-size:0.8rem; color:var(--text-muted); margin-top:2px;">
            ${t?`التطبيق محمي برمز PIN سري`:`رمز PIN غير مفعل، يوصى بتفعيله لخصوصيتك`}
          </p>
        </div>
        <span class="status-badge ${t?`badge-success`:`badge-warning`}">
          ${t?`مفعّل 🔒`:`معطّل 🔓`}
        </span>
      </div>

      <div style="display:flex; gap:10px; margin-top:12px;">
        <button class="btn-sm-action btn-pay" id="setup-pin-btn">
          ${t?`تغيير رمز PIN`:`تفعيل رمز PIN الآن`}
        </button>
        ${t?`<button class="btn-sm-action" id="remove-pin-btn" style="color:var(--danger-color);">إلغاء القفل</button>`:``}
      </div>
    </div>

    <!-- Backup & Restore Box -->
    <div class="debt-card" style="margin-bottom:16px;">
      <h3 style="font-size:1rem; font-weight:800; margin-bottom:4px;">💾 النسخ الاحتياطي والاستعادة</h3>
      <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:12px;">
        احفظ بياناتك في ملف أو انقلها إلى أي هاتف آخر بأمان وسرعة.
      </p>

      <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <button class="btn-sm-action" id="btn-export-backup">
          📥 تصدير نسخة احتياطية (JSON)
        </button>
        <button class="btn-sm-action" id="btn-import-backup">
          📤 استيراد نسخة سابقة
        </button>
        <button class="btn-sm-action" id="btn-print-statement">
          🖨️ طباعة / حفظ كشف PDF
        </button>
      </div>
    </div>

    <!-- App Info Box -->
    <div class="debt-card" style="margin-bottom:16px; font-size:0.82rem; color:var(--text-muted);">
      <h3 style="font-size:0.95rem; font-weight:800; color:var(--text-main); margin-bottom:6px;">📱 حول التطبيق</h3>
      <div>الإصدار: <strong>2.0.0 (Android Edition)</strong></div>
      <div>تقنية التخزين: <strong>IndexedDB آمن محلياً على جهازك</strong></div>
      <div>التوافق: <strong>يعمل بدون إنترنت (Offline-First) 100%</strong></div>
    </div>

    <!-- Danger Zone -->
    <div class="debt-card" style="border: 1px solid var(--danger-border); background:var(--danger-bg);">
      <h3 style="font-size:0.95rem; font-weight:800; color:var(--danger-color); margin-bottom:4px;">⚠️ منطقة الخطر</h3>
      <p style="font-size:0.8rem; color:var(--danger-color); margin-bottom:10px;">
        مسح جميع البيانات المسجلة على هذا الجهاز نهائياً.
      </p>
      <button class="btn-sm-action" id="btn-wipe-data" style="background:#fff; color:var(--danger-color); border-color:var(--danger-border);">
        مسح جميع البيانات نهائياً
      </button>
    </div>
  `,document.getElementById(`setup-pin-btn`)?.addEventListener(`click`,()=>je()),document.getElementById(`remove-pin-btn`)?.addEventListener(`click`,async()=>{confirm(`هل تريد بالتأكيد إلغاء حماية التطبيق برمز PIN؟`)&&(await de(),X())}),document.getElementById(`btn-export-backup`)?.addEventListener(`click`,()=>we()),document.getElementById(`btn-import-backup`)?.addEventListener(`click`,()=>{document.getElementById(`backup-file-input`)?.click()}),document.getElementById(`btn-print-statement`)?.addEventListener(`click`,()=>window.print()),document.getElementById(`btn-wipe-data`)?.addEventListener(`click`,async()=>{confirm(`تحذير شديد: سيتم مسح كافة الديون والمدفوعات نهائياً ولا يمكن التراجع. هل أنت متأكد؟`)&&(await p(),D(`تم مسح جميع البيانات بنجاح`,`warning`),await G(),X())})}async function we(){try{let e=await l(),t={app:`DebtManagerAndroid`,version:`5.0`,exportedAt:new Date().toISOString(),debts:e},n=new Blob([JSON.stringify(t,null,2)],{type:`application/json`}),r=URL.createObjectURL(n),i=document.createElement(`a`);i.href=r,i.download=`debt_manager_backup_${y()}.json`,i.click(),URL.revokeObjectURL(r),D(`تم تصدير ملف النسخة الاحتياطية بنجاح 📥`,`success`)}catch(e){console.error(`Export error:`,e),D(`فشل تصدير النسخة الاحتياطية`,`error`)}}document.getElementById(`backup-file-input`)?.addEventListener(`change`,async e=>{let t=e.target.files[0];if(t)try{if(!confirm(`استيراد النسخة الاحتياطية سيقوم بدمج أو تحديث الديون الحالية. هل تود المتابعة؟`)){e.target.value=``;return}let n=await t.text(),r=JSON.parse(n);if(!r.debts||!Array.isArray(r.debts))throw Error(`الملف غير صالح`);for(let e of r.debts)if(e.name&&e.amount>0){let t={...e};delete t.id,await d(t)}D(`تم استيراد البيانات بنجاح 🎉`,`success`),await G(),q(`tab-home`)}catch(e){console.error(`Import error:`,e),D(`ملف النسخة الاحتياطية غير صالح أو تالف`,`error`)}finally{e.target.value=``}});function Te(){document.querySelectorAll(`.close-modal-btn`).forEach(e=>{e.addEventListener(`click`,()=>{document.querySelectorAll(`.modal-overlay`).forEach(e=>e.classList.remove(`active`))})}),document.querySelectorAll(`.modal-overlay`).forEach(e=>{e.addEventListener(`click`,t=>{t.target===e&&e.classList.remove(`active`)})});let e=document.getElementById(`form-debt`);e&&e.addEventListener(`submit`,async e=>{e.preventDefault(),await De()});let t=document.getElementById(`form-payment`);t&&t.addEventListener(`submit`,async e=>{e.preventDefault(),await Oe()});let n=document.getElementById(`form-pin-config`);n&&n.addEventListener(`submit`,async e=>{e.preventDefault();let t=document.getElementById(`pin-input-new`).value;if(t!==document.getElementById(`pin-input-confirm`).value)D(`رمزا PIN غير متطابقين، يرجى إعادة الإدخال`,`error`);else try{await ue(t),document.getElementById(`modal-pin-config`).classList.remove(`active`),X()}catch(e){D(e.message,`error`)}});let r=document.getElementById(`debt-field-amount`);r&&r.addEventListener(`input`,()=>v(r));let i=document.getElementById(`payment-field-amount`);i&&i.addEventListener(`input`,()=>v(i));let a=document.getElementById(`debt-field-attachments`);a&&a.addEventListener(`change`,async e=>{let t=Array.from(e.target.files);for(let e of t){let t=await O(e);H.push(t)}Z(),a.value=``});let o=document.getElementById(`payment-field-attachments`);o&&o.addEventListener(`change`,async e=>{let t=Array.from(e.target.files);for(let e of t){let t=await O(e);U.push(t)}Q(),o.value=``}),document.getElementById(`pay-full-remaining-btn`)?.addEventListener(`click`,()=>{let e=document.getElementById(`payment-debt-remaining`)?.dataset.rawRemaining;if(e){let t=document.getElementById(`payment-field-amount`);t.value=g(Number(e))}})}function Z(){let e=document.getElementById(`debt-attachments-preview`);e&&(e.innerHTML=H.map((e,t)=>`
    <div style="display:flex; justify-content:space-between; align-items:center; background:var(--bg-subtle); padding:6px 10px; border-radius:var(--radius-sm); font-size:0.8rem;">
      <span>📎 ${e.name} (${k(e.size)})</span>
      <button type="button" class="icon-btn" style="width:24px; height:24px; color:var(--danger-color);" onclick="window.removeDebtAttachment(${t})">✕</button>
    </div>
  `).join(``))}window.removeDebtAttachment=e=>{H.splice(e,1),Z()};function Q(){let e=document.getElementById(`payment-attachments-preview`);e&&(e.innerHTML=U.map((e,t)=>`
    <div style="display:flex; justify-content:space-between; align-items:center; background:var(--bg-subtle); padding:6px 10px; border-radius:var(--radius-sm); font-size:0.8rem;">
      <span>📎 ${e.name} (${k(e.size)})</span>
      <button type="button" class="icon-btn" style="width:24px; height:24px; color:var(--danger-color);" onclick="window.removePayAttachment(${t})">✕</button>
    </div>
  `).join(``))}window.removePayAttachment=e=>{U.splice(e,1),Q()};async function Ee(e=null){let t=document.getElementById(`modal-debt`),n=document.getElementById(`modal-debt-title`);if(document.getElementById(`form-debt`).reset(),H=[],Z(),e){n.textContent=`تعديل بيانات الدين`;let t=await u(e);if(!t)return;document.getElementById(`debt-field-id`).value=t.id,document.getElementById(`debt-field-name`).value=t.name||``,document.getElementById(`debt-field-phone`).value=t.phone||``,document.getElementById(`debt-field-type`).value=t.type||`لي عند شخص`,document.getElementById(`debt-field-amount`).value=t.amount?g(t.amount):``,document.getElementById(`debt-field-currency`).value=t.currency||`SAR`,document.getElementById(`debt-field-debt-date`).value=t.debtDate||y(),document.getElementById(`debt-field-due-date`).value=t.dueDate||y(),document.getElementById(`debt-field-category`).value=t.category||``,document.getElementById(`debt-field-remind-days`).value=t.remindDays===void 0?3:t.remindDays,document.getElementById(`debt-field-notes`).value=t.notes||``,t.attachments&&Array.isArray(t.attachments)&&(H=[...t.attachments],Z())}else n.textContent=`إضافة دين جديد`,document.getElementById(`debt-field-id`).value=``,document.getElementById(`debt-field-debt-date`).value=y(),document.getElementById(`debt-field-due-date`).value=y(),document.getElementById(`debt-field-remind-days`).value=`3`;t.classList.add(`active`)}async function De(){let e=document.getElementById(`debt-field-id`).value,t=document.getElementById(`debt-field-name`).value.trim(),n=document.getElementById(`debt-field-phone`).value.trim(),r=document.getElementById(`debt-field-type`).value,i=document.getElementById(`debt-field-amount`).value,a=_(i),o=document.getElementById(`debt-field-currency`).value,s=document.getElementById(`debt-field-debt-date`).value,c=document.getElementById(`debt-field-due-date`).value,l=document.getElementById(`debt-field-category`).value.trim(),f=parseInt(document.getElementById(`debt-field-remind-days`).value,10)||0,p=document.getElementById(`debt-field-notes`).value.trim();if(!t){D(`يرجى إدخال اسم الشخص أو الجهة`,`error`);return}if(a<=0){D(`يجب أن يكون المبلغ أكبر من صفر`,`error`);return}if(!s||!c){D(`التواريخ مطلوبة`,`error`);return}if(x(s,c)<0){D(`⚠️ تاريخ الاستحقاق لا يمكن أن يكون قبل تاريخ المديونية`,`error`);return}let m=[];if(e){let t=await u(e);t&&t.payments&&(m=t.payments)}let h={name:t,phone:n,type:r,amount:a,currency:o,debtDate:s,dueDate:c,category:l,remindDays:f,notes:p,payments:m,attachments:H};e&&(h.id=Number(e)),await d(h),document.getElementById(`modal-debt`).classList.remove(`active`),D(e?`تم تحديث المديونية بنجاح`:`تمت إضافة المديونية بنجاح 🎉`,`success`),await G()}async function $(e,t=null){let n=await u(e);if(!n)return;let r=w(n);if(r<=0&&t===null){D(`تم سداد هذا الدين بالكامل مسبقاً!`,`warning`);return}let i=document.getElementById(`modal-payment`),a=document.getElementById(`modal-payment-title`);document.getElementById(`form-payment`).reset(),U=[],Q(),document.getElementById(`payment-debt-id`).value=n.id,document.getElementById(`payment-edit-index`).value=t===null?``:t,document.getElementById(`payment-debt-name`).textContent=`${n.name} (${n.type})`;let o=document.getElementById(`payment-debt-remaining`);if(o.textContent=g(r,n.currency),o.dataset.rawRemaining=r,t!==null){a.textContent=`تعديل دفعة سداد`;let e=n.payments[t];document.getElementById(`payment-field-amount`).value=g(e.amount),document.getElementById(`payment-field-date`).value=e.date||y(),document.getElementById(`payment-field-method`).value=e.method||`تحويل بنكي`,document.getElementById(`payment-field-notes`).value=e.notes||``,e.attachments&&(U=[...e.attachments],Q())}else a.textContent=`تسجيل دفعة سداد جديدة`,document.getElementById(`payment-field-date`).value=y();i.classList.add(`active`)}async function Oe(){let e=document.getElementById(`payment-debt-id`).value,t=document.getElementById(`payment-edit-index`).value,n=t!==``,r=n?parseInt(t,10):null,i=document.getElementById(`payment-field-amount`).value,a=_(i),o=document.getElementById(`payment-field-date`).value,s=document.getElementById(`payment-field-method`).value,c=document.getElementById(`payment-field-notes`).value.trim();if(a<=0){D(`يجب إدخال مبلغ صحيح للدفعة`,`error`);return}let l=await u(e);if(!l)return;let f=l.payments?[...l.payments]:[],p=f.reduce((e,t,i)=>n&&i===r?e:e+(Number(t.amount)||0),0)+a;if(p>l.amount&&!confirm(`المبلغ المدخل (${g(a)}) يجعل إجمالي المسدد يتجاوز أصل الدين بمقدار ${g(p-l.amount)}. هل ترغب بالمتابعة؟`))return;let m={id:n&&f[r].id||Date.now(),amount:a,date:o,method:s,notes:c,attachments:U};n?f[r]=m:f.push(m),l.payments=f,await d(l),document.getElementById(`modal-payment`).classList.remove(`active`),D(n?`تم تعديل الدفعة بنجاح`:`تم تسجيل الدفعة بنجاح 💵`,`success`),p>=l.amount&&ke(),await G()}function ke(){try{t({particleCount:80,spread:70,origin:{y:.6}})}catch{}}async function Ae(e){let t=await u(e);if(!t)return;let n=document.getElementById(`modal-view-details`),r=document.getElementById(`view-details-title`),i=document.getElementById(`view-details-body`),a=document.getElementById(`view-details-footer`),o=E(t),s=Number(t.amount)||0,c=C(t),l=w(t),d=t.currency||`SAR`,f=t.payments||[];r.textContent=`كشف تفصيلي: ${t.name}`;let p=``;p=f.length===0?`<p style="font-size:0.85rem; color:var(--text-muted);">لم يتم تسجيل أي دفعات حتى الآن.</p>`:`
      <div style="display:flex; flex-direction:column; gap:8px;">
        ${f.map((e,n)=>`
          <div style="background:var(--bg-subtle); border:1px solid var(--bg-border); border-radius:var(--radius-md); padding:10px 12px; display:flex; justify-content:space-between; align-items:center;">
            <div>
              <div style="font-weight:800; font-family:var(--font-numeric); color:var(--lana-color);">+ ${g(e.amount,d)}</div>
              <div style="font-size:0.75rem; color:var(--text-muted);">${S(e.date)} • ${e.method||`تحويل`} ${e.notes?`(${e.notes})`:``}</div>
              ${e.attachments&&e.attachments.length>0?`<div style="margin-top:4px; font-size:0.72rem;">📎 ${e.attachments.length} مرفق إثبات</div>`:``}
            </div>
            <div style="display:flex; gap:4px;">
              <button class="icon-btn" style="width:30px; height:30px;" onclick="window.editPaymentRecord(${t.id}, ${n})">✏️</button>
              <button class="icon-btn" style="width:30px; height:30px; color:var(--danger-color);" onclick="window.deletePaymentRecord(${t.id}, ${n})">🗑️</button>
            </div>
          </div>
        `).join(``)}
      </div>
    `;let m=``;t.attachments&&t.attachments.length>0&&(m=`
      <div style="margin-top:12px;">
        <h4 style="font-size:0.9rem; font-weight:800; margin-bottom:6px;">مستندات الدين:</h4>
        <div style="display:flex; flex-direction:column; gap:6px;">
          ${t.attachments.map(e=>`
            <div style="display:flex; justify-content:space-between; align-items:center; background:var(--bg-subtle); padding:6px 10px; border-radius:var(--radius-sm); font-size:0.8rem;">
              <span>📎 ${e.name} (${k(e.size)})</span>
              <a href="${e.data}" download="${e.name}" class="btn-sm-action" style="padding:3px 8px;">⬇ تحميل</a>
            </div>
          `).join(``)}
        </div>
      </div>
    `),i.innerHTML=`
    <!-- Top Details Grid -->
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; background:var(--bg-subtle); padding:12px; border-radius:var(--radius-md);">
      <div><strong>النوع:</strong> ${t.type}</div>
      <div><strong>الحالة:</strong> <span class="status-badge ${o.badgeClass}">${o.title}</span></div>
      <div><strong>تاريخ الدين:</strong> ${S(t.debtDate)}</div>
      <div><strong>تاريخ الاستحقاق:</strong> ${S(t.dueDate)}</div>
      <div><strong>التصنيف:</strong> ${t.category||`-`}</div>
      <div><strong>رقم الجوال:</strong> ${t.phone||`-`}</div>
    </div>

    <!-- Financial Progress -->
    <div class="debt-amount-row" style="margin-top:12px;">
      <div class="amount-col">
        <div class="amount-label">الأصل</div>
        <div class="amount-val">${g(s,d)}</div>
      </div>
      <div class="amount-col">
        <div class="amount-label">المسدد (${o.percentage}%)</div>
        <div class="amount-val" style="color:var(--lana-color);">${g(c,d)}</div>
      </div>
      <div class="amount-col rem-col">
        <div class="amount-label">المتبقي</div>
        <div class="amount-val">${g(l,d)}</div>
      </div>
    </div>

    ${t.notes?`<div style="margin-top:10px; font-size:0.85rem;"><strong>ملاحظات:</strong> ${t.notes}</div>`:``}

    ${m}

    <div style="margin-top:16px;">
      <h4 style="font-size:0.95rem; font-weight:800; margin-bottom:8px;">سجل الدفعات (${f.length}):</h4>
      ${p}
    </div>
  `,a.innerHTML=`
    ${l>0?`<button class="btn-primary" onclick="window.payFromView(${t.id})">⚡ تسجيل دفعة جديدة</button>`:``}
    <button class="btn-secondary close-modal-btn">إغلاق</button>
  `,a.querySelector(`.close-modal-btn`)?.addEventListener(`click`,()=>{n.classList.remove(`active`)}),n.classList.add(`active`)}window.payFromView=e=>{document.getElementById(`modal-view-details`).classList.remove(`active`),$(e)},window.editPaymentRecord=(e,t)=>{document.getElementById(`modal-view-details`).classList.remove(`active`),$(e,t)},window.deletePaymentRecord=async(e,t)=>{if(confirm(`هل أنت متأكد من حذف هذه الدفعة من السجل؟`)){let n=await u(e);if(!n||!n.payments)return;n.payments.splice(t,1),await d(n),D(`تم حذف الدفعة`),await G(),Ae(e)}};function je(){document.getElementById(`pin-input-new`).value=``,document.getElementById(`pin-input-confirm`).value=``,document.getElementById(`modal-pin-config`).classList.add(`active`)}function Me(){document.querySelectorAll(`.keypad-btn[data-key]`).forEach(e=>{e.addEventListener(`click`,()=>{se(e.dataset.key)})}),document.getElementById(`keypad-backspace`)?.addEventListener(`click`,()=>{ce()}),document.getElementById(`keypad-clear`)?.addEventListener(`click`,()=>{for(let e=0;e<4;e++)ce()})}async function Ne(){try{let e=y(),t=L.filter(t=>w(t)<=0?!1:x(e,t.dueDate)<=(t.remindDays===void 0?3:t.remindDays));t.length>0&&`Notification`in window&&Notification.permission===`granted`&&new Notification(`🔔 تذكير استحقاق الديون`,{body:`لديك ${t.length} مديونيات قريبة أو متأخرة تحتاج إلى المتابعة.`})}catch{}}document.addEventListener(`DOMContentLoaded`,pe);